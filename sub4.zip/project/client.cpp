#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <csignal>
#include <fcntl.h>
#include <map>

using namespace std;
volatile sig_atomic_t status = 1;

#define PAYLOAD_SIZE 1024
#define HEADER_SIZE 12
#define PACKET_SIZE (PAYLOAD_SIZE + HEADER_SIZE)
#define WINDOW_SIZE 20
#define MSS 1024

typedef struct __attribute__((__packed__)) {
    uint32_t seq;
    uint32_t ack;
    uint16_t size;
    uint8_t padding[2];
    uint8_t data[MSS];
} packet;

void packet_to_network_order(packet* pkt) {
    pkt->seq = htonl(pkt->seq);
    pkt->ack = htonl(pkt->ack);
    pkt->size = htons(pkt->size);
}

void packet_to_host_order(packet* pkt) {
    pkt->seq = ntohl(pkt->seq);
    pkt->ack = ntohl(pkt->ack);
    pkt->size = ntohs(pkt->size);
}

void cleanup(int sockfd) {
    close(sockfd);
    // cout.flush();
}


void dumpMessage(packet* serverPacket) {
    if (serverPacket->seq == 0) {
        return;
    }
    write(STDOUT_FILENO, serverPacket->data, serverPacket->size);
}

void sendAck(int sockfd, struct sockaddr_in serverAddress, int &lastSentAck) {
    packet ACK = {0};
    ACK.seq = 0; // Sequence number for ACK packet is set to 0
    ACK.ack = htonl(lastSentAck); // Convert ack to network byte order
    int sent = sendto(sockfd, &ACK, HEADER_SIZE, 0, (struct sockaddr*)&serverAddress, sizeof(serverAddress));
    if (sent != -1) {
        // cout << "Sent ack for: " << lastSentAck << endl;
    }
}

void sendData(int sockfd, struct sockaddr_in serverAddress, char inputBuff[1024], int dataSize, int &clientSeq, int lastSentAck) {
    // cout << dataSize << endl;
    packet clientData = {0};
    clientData.seq = htonl(clientSeq); // Convert seq to network byte order
    clientData.ack = htonl(lastSentAck); // Convert ack to network byte order
    clientData.size = htons(dataSize); // Convert size to network byte order
    memcpy(clientData.data, inputBuff, dataSize);
    // cout << clientData.size << endl;
    // cout << "size of server data " << HEADER_SIZE + dataSize<< endl;
    // cout << "yes" << endl;
    // write(STDOUT_FILENO, inputBuff, dataSize);
    // write(STDOUT_FILENO, clientData.data, dataSize);

    // cout << "Packet Size: "<< HEADER_SIZE + dataSize << endl;
    // cout << dataSize << "," << clientData.size << endl;
    // exit(1);

    // cout << HEADER_SIZE + dataSize << endl;

    int sent = sendto(sockfd, &clientData, HEADER_SIZE + dataSize, 0, (struct sockaddr*)&serverAddress, sizeof(serverAddress));

    if (sent != -1) {
        clientSeq++;
    }
}

void processData(int sockfd, struct sockaddr_in serverAddress, packet* serverPacket, int &lastSentACK, int &lastRecAck, map<uint32_t, packet> &bufferedPackets) {
    packet_to_host_order(serverPacket);
    // cout << "Received packet with seq: " << serverPacket->seq << " and ack: " << serverPacket->ack << endl;
    
    if (serverPacket->seq == 0) {
        lastRecAck = serverPacket->ack;
        // cout << "RECV 0 ACK " <<  serverPacket->ack << endl;
        return;
    }
    
    if (serverPacket->seq == lastSentACK + 1) {
        dumpMessage(serverPacket);
        // cout << "RECV " << serverPacket->seq << " ACK " << serverPacket->ack << endl;
        lastSentACK++;

        // while (bufferedPackets.count(lastSentACK) > 0) {
        //     packet pkt = bufferedPackets[lastSentACK];
        //     dumpMessage(&pkt);
        //     bufferedPackets.erase(lastSentACK);
        //     lastSentACK++;
        // }

    } 
    // else if (serverPacket->seq > lastSentACK) {
    //     bufferedPackets[serverPacket->seq] = *serverPacket;
    // }

    sendAck(sockfd, serverAddress, lastSentACK);
}

int sockfd;

void sig(int signal) {
    status = 0;
    close(STDIN_FILENO);
    cleanup(sockfd);
    exit(0);
}

int main(int argc, char *argv[]) {
    if (argc != 5) {
        // cout << "Not enough arguments for client" << endl;
        return -1;
    }

    int securityFlag = stoi(argv[1]);
    string host = argv[2];
    string pubKey = argv[4];

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        exit(errno);
    }

    int flags = fcntl(sockfd, F_GETFL);
    flags |= O_NONBLOCK;
    fcntl(sockfd, F_SETFL, flags);

    int stdin_flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, stdin_flags | O_NONBLOCK);

    struct sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = inet_addr("127.0.0.1");

    int PORT = stoi(argv[3]);
    serverAddress.sin_port = htons(PORT);

    const int trueFlag = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &trueFlag, sizeof(int)) == -1) {
        perror("setsockopt");
        return errno;
    }

    char server_buf[sizeof(packet) + MSS];
    socklen_t serverSize;

    // int BUF_SIZE = 1024;
    // char inputBuff[BUF_SIZE];

    signal(SIGINT, sig);

    int clientSeq = 1;
    int lastSentACK = 0;
    int lastRecAck = 0;

    map<uint32_t, packet> bufferedPackets;

    while (status == 1) {

        int BUF_SIZE = 1024;
        char inputBuff[BUF_SIZE];

        int messageBytes = read(STDIN_FILENO, inputBuff, BUF_SIZE);

        if (messageBytes > 0) {
            // cout << messageBytes << endl;
            // cout << "Message bytes: "<< messageBytes << endl;
            // write(STDOUT_FILENO, messageBytes, sizeof(messageBytes));
            sendData(sockfd, serverAddress, inputBuff, messageBytes, clientSeq, lastSentACK);
        }
        // exit(1);

        int bytes_recvd = recvfrom(sockfd, &server_buf, sizeof(server_buf), 0, (struct sockaddr*)&serverAddress, &serverSize);

        if (bytes_recvd > 0) {
            // cout << "bytes_recvd: "<< bytes_recvd << endl;
            // exit(1);
            // cout << "bytes_recvd" << endl;
            packet* serverPacket = (packet*)&server_buf;
            processData(sockfd, serverAddress, serverPacket, lastSentACK, lastRecAck, bufferedPackets);
        }
    }

    cleanup(sockfd);
    return 0;
}
